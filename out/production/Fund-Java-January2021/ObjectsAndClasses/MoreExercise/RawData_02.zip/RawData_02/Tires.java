package ObjectsAndClasses.MoreExercise.RawData_02;

public class Tires {
    private double tyrePressure;
    private int typeAge;

    public Tires(double tyrePressure, int typeAge) {
        this.tyrePressure = tyrePressure;
        this.typeAge = typeAge;
    }

    public double getTyrePressure() {
        return tyrePressure;
    }
}
